

<?php

define ( 'TAMAÑOMAX', 300000);

// se incluyen esta tabla de  códigos de error que produce la subida de archivos en PHPP
// Posibles errores de subida segun el manual de PHP
$codigosErrorSubida= [ 
    UPLOAD_ERR_OK         => 'Subida correcta',  // Valor 0
    UPLOAD_ERR_INI_SIZE   => 'El tamaño del archivo excede el admitido por el servidor',  // directiva upload_max_filesize en php.ini
    UPLOAD_ERR_FORM_SIZE  => 'El tamaño del archivo excede el admitido por el cliente',  // directiva MAX_FILE_SIZE en el formulario HTML
    UPLOAD_ERR_PARTIAL    => 'El archivo no se pudo subir completamente',
    UPLOAD_ERR_NO_FILE    => 'No se seleccionó ningún archivo para ser subido',
    UPLOAD_ERR_NO_TMP_DIR => 'No existe un directorio temporal donde subir el archivo',
    UPLOAD_ERR_CANT_WRITE => 'No se pudo guardar el archivo en disco',  // permisos
    UPLOAD_ERR_EXTENSION  => 'Una extensión PHP evito la subida del archivo',  // extensión PHP

]; 


$mensaje = '';

    var_dump($_FILES);
    $ruta = '/home/alumnoa/tallerphp/Tema3/imgusers'; //directorio de alojamiento
    if  ( empty ($_FILES['archivos']['name'][0] )){
        echo " No hay ficheros";
        exit();
    }

    $Ficheros = $_FILES['archivos']['name'];
    $Ficherosnumero = count($Ficheros);


    for($i=0;$i<$Ficherosnumero;$i++){

        // No se recibe nada, error al enviar el POST, se supera post_max_size
        if (count($_POST) == 0 ){
        $mensaje= "  Error: se supera el tamaño máximo de un petición POST ";
        }
        // si no se reciben el directorio de alojamiento y el archivo, se descarta el proceso
        
        else {
            
            $nombreFichero   =   $_FILES['archivos']['name'][$i];
            
            $tipoFichero     =   $_FILES['archivos']['type'][$i];

            $tamanioFichero  =   $_FILES['archivos']['size'][$i];

            $errorFichero    =   $_FILES['archivos']['error'][$i];

            $temporalFichero =   $_FILES['archivos']['tmp_name'][$i];

            

            $mensaje .= 'Intentando subir el archivo: ' . ' <br />';
            $mensaje .= "- Nombre: $nombreFichero" . ' <br />';
            $mensaje .= '- Tamaño: ' . number_format(($tamanioFichero / 1000), 1, ',', '.'). ' KB <br />';
            $mensaje .= "- Tipo: $tipoFichero" . ' <br />' ;
            $mensaje .= "- Nombre archivo temporal: $temporalFichero" . ' <br />';
            $mensaje .= "- Código de estado: $errorFichero" . ' <br />';
            
            $mensaje .= '<br />RESULTADO<br />';


          

            $total=0;
            foreach ($_FILES['archivos']['size'] as $value) {
                $total+=$value;//$total=$total+$value
                //$mensaje.=$total;
                if($total > TAMAÑOMAX){
                    $mensaje .= 'ERROR: El conjunto de archivos supera los 300kb <br />';
                    exit();
                }
            }
            
            //Comprueba que el archivo existe
            if(file_exists($ruta."/".$_FILES['archivos']['name'][$i])==false){
                // Comprueba el peso
                if ($tamanioFichero < 200000) {
                // Obtengo el código de error de la operación, 0 si todo ha ido bien
                    if ($errorFichero > 0) {
                        $mensaje .= "Se ha producido el error nº $errorFichero[$i]: <em>" 
                                    . $codigosErrorSubida[$errorFichero[$i]] . '</em> <br />';
                    } else { // subida correcta del temporal
                        // si es un directorio y tengo permisos     
                        if ( is_dir($ruta) && is_writable ($ruta)) { 
                            //Intento mover el archivo temporal al directorio indicado
                            
                            if (move_uploaded_file($temporalFichero,  $ruta .'/'. $nombreFichero) == true) {
                                $mensaje .= 'Archivo guardado en: ' . $ruta .'/'. $nombreFichero . ' <br />';

                            } else {
                                $mensaje .= 'ERROR: Archivo no guardado correctamente <br />';
                                }

                        } else {
                            $mensaje .= 'ERROR: No es un directorio correcto o no se tiene permiso de escritura <br />';
                            }
                        }
                }else  $mensaje .= 'ERROR: El archivo pesa mas de 200kb <br />';

            } else  $mensaje .= 'ERROR: El archivo ya existe <br />';
        }
    }
?>
<?= $mensaje; ?>