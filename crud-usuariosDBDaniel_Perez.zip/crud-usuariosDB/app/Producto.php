<?php


class Producto
{
    public $PRODUCTO_NO;
    public $DESCRIPCION;
    public $PRECIO_ACTUAL;
    public $STOCK_DISPONIBLE;
    
}

